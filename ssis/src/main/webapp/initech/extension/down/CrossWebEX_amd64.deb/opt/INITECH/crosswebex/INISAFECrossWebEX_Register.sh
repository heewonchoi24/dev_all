#!/bin/bash

function check_write(){
	FILE_MODE=`stat -c %a $1`
	FILE_USER=`stat -c %U $1`
	USERID=$2

	if [ -d $1 ]
	then
		if [ $FILE_USER != $USERID ]
		then
		        echo "ERROR: Can not write to directroy. ($1)"
		        return -1
		fi


		USER_WRITE_PER=`expr substr $FILE_MODE 1 1`

		if [ $USER_WRITE_PER -ne 7 ] &&
		   [ $USER_WRITE_PER -ne 6 ]
		then
		        echo "ERROR: Can not write to directroy. ($1)"
		        return -1
		fi
	
		return 0
	else
		echo "ERROR: Can not find directroy, ($1)"
		return -1
	fi
}

function print_writeerror(){
	ERROR_MESSAGE="ERROR: Can not regist INISAFE CrossWeb EX autostart script."
	ERROR_MESSAGE2="       INISAFE CrossWeb EX install FAILED."
	ERROR_MESSAGE3="       You can retry after changed directroy permission."

	 echo "${ERROR_MESSAGE}"
         echo "${ERROR_MESSAGE2}"
         echo "${ERROR_MESSAGE3}"
         echo "       ($1)"
}

CONFIG_DIR="${HOME}/.config"
AUTOSTART_DIR="${CONFIG_DIR}/autostart"

check_write $CONFIG_DIR $USER
if [ $? -eq 0 ]
then 
	if [ -d $AUTOSTART_DIR ]
	then
		check_write $AUTOSTART_DIR $USER
		if [ $? -ne 0 ]
		then
			print_writeerror $AUTOSTART_DIR
			exit -1
		fi
	fi
else
	print_writeerror $CONFIG_DIR
	exit -1
fi


exit 0

